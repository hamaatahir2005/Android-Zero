"""Explicit local Android emulator lifecycle management; no remote device operations."""
import os
import re
import shutil
import subprocess
from pathlib import Path

_AVD = re.compile(r'^[A-Za-z0-9_.-]{1,100}$')

def tool_path(name):
    direct = shutil.which(name)
    if direct:
        return direct
    sdk = os.environ.get('ANDROID_SDK_ROOT') or os.environ.get('ANDROID_HOME')
    if not sdk:
        return None
    candidates = {'adb':['platform-tools/adb'], 'emulator':['emulator/emulator']}.get(name, [])
    for item in candidates:
        p = Path(sdk) / item
        for candidate in (p, Path(str(p)+'.exe')):
            if candidate.is_file():
                return str(candidate)
    return None

def dependency_status():
    return {'android_sdk': os.environ.get('ANDROID_SDK_ROOT') or os.environ.get('ANDROID_HOME'),
            'adb': tool_path('adb'), 'emulator': tool_path('emulator')}

def list_profiles():
    exe=tool_path('emulator')
    if not exe:
        raise FileNotFoundError('Android emulator missing; install Android SDK Emulator')
    result=subprocess.run([exe,'-list-avds'],capture_output=True,text=True,timeout=15)
    if result.returncode:
        raise RuntimeError(result.stderr.strip() or 'Unable to list emulator profiles')
    return [x.strip() for x in result.stdout.splitlines() if _AVD.fullmatch(x.strip())]

def start_profile(profile):
    if not _AVD.fullmatch(profile):
        raise ValueError('Invalid emulator profile name')
    if profile not in list_profiles():
        raise ValueError('Emulator profile does not exist')
    exe=tool_path('emulator')
    process=subprocess.Popen([exe,'-avd',profile,'-no-snapshot-save'],stdin=subprocess.DEVNULL,
                             stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    return process.pid

def stop_local_emulator(serial):
    if not re.fullmatch(r'emulator-\d{4,6}',serial):
        raise ValueError('Only local emulator serials are supported')
    exe=tool_path('adb')
    if not exe:
        raise FileNotFoundError('ADB missing')
    devices=subprocess.run([exe,'devices'],capture_output=True,text=True,timeout=15)
    if devices.returncode or not any(line.startswith(serial+'\tdevice') for line in devices.stdout.splitlines()):
        raise ValueError('Local emulator is not connected and authorized')
    result=subprocess.run([exe,'-s',serial,'emu','kill'],capture_output=True,text=True,timeout=15)
    if result.returncode:
        raise RuntimeError(result.stderr.strip() or 'Unable to stop emulator')
    return True
