"""Isolated, local-only sanitizer smoke testing for bundled teaching fixtures."""
from pathlib import Path
import os
import shutil
import subprocess
import tempfile


def compiler():
    return shutil.which('clang') or shutil.which('clang++')


def run_fixture(source: Path, payload: bytes = b'hello\n', timeout: int = 8):
    """Compile a local C teaching fixture with ASan/UBSan and collect evidence.

    No device interaction, remote target, or exploit reproduction is performed.
    """
    source = Path(source).resolve()
    if source.name not in ('parser.c', 'unsafe_demo.c') or source.parent.name != 'samples':
        raise ValueError('Only bundled teaching fixtures are supported')
    cc = compiler()
    if not cc:
        return {'status': 'unavailable', 'reason': 'Clang not installed'}
    with tempfile.TemporaryDirectory(prefix='androidlab_san_') as td:
        binary = Path(td) / ('fixture.exe' if os.name == 'nt' else 'fixture')
        build = subprocess.run([cc, '-g', '-O1', '-fno-omit-frame-pointer',
            '-fsanitize=address,undefined', str(source), '-o', str(binary)],
            capture_output=True, text=True, timeout=timeout)
        if build.returncode:
            return {'status': 'build_failed', 'compiler_output': (build.stderr or build.stdout)[-4000:]}
        try:
            run = subprocess.run([str(binary)], input=payload[:4096], capture_output=True,
                                 timeout=timeout, env={**os.environ, 'ASAN_OPTIONS': 'detect_leaks=0'})
        except subprocess.TimeoutExpired:
            return {'status': 'timeout', 'fixture': source.name}
        log = (run.stderr + b'\n' + run.stdout).decode('utf-8', errors='replace')[-10000:]
        finding = 'AddressSanitizer' in log or 'runtime error:' in log
        return {'status': 'sanitizer_finding' if finding else ('completed' if run.returncode == 0 else 'nonzero_exit'),
                'fixture': source.name, 'exit_code': run.returncode,
                'sanitizer_evidence': finding, 'output': log,
                'classification': 'teaching fixture only; not an Android vulnerability'}
