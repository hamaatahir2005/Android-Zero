"""Local authorized source analysis: CodeQL CLI, SARIF import and evidence triage.

No device exploitation, payload delivery, or remote scanning.
"""
import json
import shutil
import subprocess
import tempfile
from pathlib import Path
from .codeql_analysis import import_sarif, compare_findings

LANGUAGES = {'java': 'java-kotlin', 'cpp': 'cpp', 'python': 'python'}


def codeql_available():
    return shutil.which('codeql') is not None


def run_codeql(source_root, language='java', suite=None, timeout=1200):
    root = Path(source_root).resolve(strict=True)
    if not root.is_dir():
        raise ValueError('Source must be a directory')
    if language not in LANGUAGES:
        raise ValueError('Unsupported CodeQL language')
    binary = shutil.which('codeql')
    if not binary:
        raise RuntimeError('CodeQL CLI not installed or not on PATH')
    # CodeQL defaults to a published security-and-quality query suite.
    query = suite or f'codeql/{language}-queries:codeql-suites/{language}-security-and-quality.qls'
    with tempfile.TemporaryDirectory(prefix='androidlab-codeql-') as tmp:
        db = Path(tmp) / 'db'
        sarif = Path(tmp) / 'findings.sarif'
        cmds = [
            [binary, 'database', 'create', str(db), f'--language={LANGUAGES[language]}', f'--source-root={root}', '--overwrite'],
            [binary, 'database', 'analyze', str(db), query, '--format=sarif-latest', f'--output={sarif}'],
        ]
        logs = []
        for cmd in cmds:
            try:
                result = subprocess.run(cmd, cwd=root, capture_output=True, text=True, timeout=timeout, check=False)
            except subprocess.TimeoutExpired as exc:
                raise RuntimeError('CodeQL timed out') from exc
            logs.append((result.stdout + '\n' + result.stderr)[-5000:])
            if result.returncode:
                raise RuntimeError(f'CodeQL failed (exit {result.returncode}): {logs[-1][-1500:]}')
        if not sarif.is_file():
            raise RuntimeError('CodeQL did not create a SARIF report')
        findings = import_sarif(sarif, root=root)
        return {'findings': findings, 'logs': logs, 'source_root': str(root), 'status': 'potential_only'}


def triage(semgrep_findings, codeql_findings, crash_text=''):
    overlap = compare_findings(semgrep_findings, codeql_findings)
    crash = {'sanitizer_evidence_present': any(s in crash_text for s in ('ERROR: AddressSanitizer:', 'runtime error:', 'ERROR: UndefinedBehaviorSanitizer:')),
             'reproduction_verified': False,
             'reason': 'Crash text alone does not establish source-level reproducibility or impact'}
    return {'static_analysis': overlap, 'crash_evidence': crash,
            'confirmed_android_vulnerabilities': 0,
            'next_step': 'Reproduce in an isolated fixture, capture build/version and sanitizer trace, then verify a patch'}
