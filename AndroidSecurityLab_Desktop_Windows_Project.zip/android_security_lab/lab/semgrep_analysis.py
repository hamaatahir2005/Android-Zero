"""Offline Semgrep wrapper for user-selected local source trees.
No network rules, automatic downloads, or remote scanning.
"""
import json
import shutil
import subprocess
from pathlib import Path

import sys
RULES_FILE = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent.parent)) / 'rules' / 'android-local.yml'

def parse_semgrep_json(raw, root):
    data = json.loads(raw)
    findings = []
    for result in data.get('results', []):
        extra = result.get('extra') or {}
        start = result.get('start') or {}
        path = Path(result.get('path', ''))
        try:
            display_path = str(path.resolve().relative_to(Path(root).resolve()))
        except ValueError:
            display_path = str(path)
        findings.append({
            'rule': str(result.get('check_id', 'unknown')),
            'severity': str(extra.get('severity', 'WARNING')).lower(),
            'file': display_path,
            'line': int(start.get('line', 0)),
            'evidence': str(extra.get('lines', ''))[:200],
            'recommendation': str(extra.get('message', 'Manual review required')),
            'status': 'potential',
        })
    return findings

def scan_local(root, executable=None, rules_file=None, timeout=180):
    root = Path(root).resolve()
    if not root.is_dir():
        raise ValueError('Select an existing local source folder')
    executable = executable or shutil.which('semgrep')
    if not executable:
        raise RuntimeError('Semgrep is not installed. Install it locally and retry.')
    rules = Path(rules_file or RULES_FILE).resolve()
    if not rules.is_file():
        raise FileNotFoundError('Local Semgrep rules file is missing')
    proc = subprocess.run([str(executable), 'scan', '--config', str(rules), '--json', '--metrics=off', '--disable-version-check', '--no-git-ignore', str(root)], capture_output=True, text=True, timeout=timeout, check=False)
    if proc.returncode not in (0, 1):
        raise RuntimeError((proc.stderr or proc.stdout)[:1500])
    if not proc.stdout.strip():
        raise RuntimeError('Semgrep returned no JSON output: ' + proc.stderr[:500])
    return parse_semgrep_json(proc.stdout, root)
