"""Local-only security analysis utilities; no remote target functionality."""
import json, os, re, shutil, sqlite3, subprocess, time
from pathlib import Path

RULES = [
 ('PY-EVAL','high',r'\beval\s*\(', 'Review dynamic code evaluation'),
 ('PY-SHELL','medium',r'shell\s*=\s*True', 'Review shell execution'),
 ('C-STRCPY','medium',r'\bstrcpy\s*\(', 'Review unbounded string copy'),
 ('C-GETS','high',r'\bgets\s*\(', 'Replace unsafe input routine'),
 ('JAVA-WEBVIEW','medium',r'setJavaScriptEnabled\s*\(\s*true\s*\)', 'Review WebView JavaScript exposure'),
]
EXTS={'.py','.c','.cc','.cpp','.h','.hpp','.java','.kt'}
MAX_SIZE=1024*1024

def scan(root):
 root=Path(root).resolve()
 if not root.is_dir(): raise ValueError('Choose a local source directory')
 findings=[]
 for folder, dirs, files in os.walk(root):
  dirs[:]=[d for d in dirs if d not in {'.git','node_modules','.venv','build','dist'}]
  for name in files:
   path=Path(folder)/name
   if path.suffix.lower() not in EXTS or path.is_symlink(): continue
   try:
    if path.stat().st_size>MAX_SIZE: continue
    for lineno,line in enumerate(path.read_text(encoding='utf8',errors='replace').splitlines(),1):
     for rule,severity,pattern,advice in RULES:
      if re.search(pattern,line):
       findings.append({'rule':rule,'severity':severity,'file':str(path.relative_to(root)),'line':lineno,'evidence':line.strip()[:200],'recommendation':advice,'status':'potential'})
   except (OSError,UnicodeError): continue
 return findings

def parse_crash(text):
 return {'sanitizer': ('AddressSanitizer' if 'AddressSanitizer' in text else 'UndefinedBehaviorSanitizer' if 'UndefinedBehaviorSanitizer' in text else 'unknown'), 'summary': next((x.strip() for x in text.splitlines() if 'ERROR:' in x or 'runtime error:' in x),'No recognized sanitizer signature'), 'confirmed':False}

def detect_tools():
 return {name:shutil.which(name) for name in ('adb','emulator','semgrep','codeql','clang','docker')}

def run_tool(name,args,timeout=15):
 exe=shutil.which(name)
 if not exe: raise FileNotFoundError(name+' is not installed or not in PATH')
 return subprocess.run([exe,*args],capture_output=True,text=True,timeout=timeout,check=False)

def devices():
 result=run_tool('adb',['devices','-l'])
 if result.returncode: raise RuntimeError(result.stderr)
 return result.stdout

def emulators():
 result=run_tool('emulator',['-list-avds'])
 if result.returncode: raise RuntimeError(result.stderr)
 return result.stdout

def init_db(path):
 conn=sqlite3.connect(path)
 conn.execute('CREATE TABLE IF NOT EXISTS scans (id INTEGER PRIMARY KEY, timestamp TEXT DEFAULT CURRENT_TIMESTAMP, root TEXT, findings TEXT)')
 conn.commit(); return conn

def store_scan(conn,root,findings):
 conn.execute('INSERT INTO scans(root,findings) VALUES (?,?)',(str(root),json.dumps(findings)))
 conn.commit()

def export_json(path,findings):
 Path(path).write_text(json.dumps({'schema':'android-security-lab/v1','findings':findings},indent=2),encoding='utf8')

def export_pdf(path,findings):
 from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer
 from reportlab.lib.styles import getSampleStyleSheet
 from xml.sax.saxutils import escape
 styles=getSampleStyleSheet(); story=[Paragraph('Android Security Research Lab',styles['Title']),Paragraph('Static heuristic findings; not confirmed vulnerabilities',styles['Normal']),Spacer(1,15)]
 for f in findings[:500]:
  story.append(Paragraph(escape(f"{f['rule']} | {f['severity']} | {f['file']}:{f['line']}"),styles['Heading3']))
  story.append(Paragraph(escape(f['recommendation']),styles['Normal']))
 if not findings: story.append(Paragraph('No findings in this scan.',styles['Normal']))
 SimpleDocTemplate(str(path)).build(story)
