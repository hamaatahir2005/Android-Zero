"""Local-only CodeQL SARIF importer and finding comparison.

No CodeQL downloads, repository access, or automatic execution.
"""
import json
from pathlib import Path


def import_sarif(path, root=None):
    data = json.loads(Path(path).read_text(encoding='utf-8'))
    if data.get('version') != '2.1.0':
        raise ValueError('Expected SARIF 2.1.0')
    findings = []
    for run in data.get('runs', []):
        for result in run.get('results', []):
            locations = result.get('locations') or []
            physical = ((locations[0].get('physicalLocation') or {}) if locations else {})
            uri = (physical.get('artifactLocation') or {}).get('uri', '')
            line = (physical.get('region') or {}).get('startLine', 0)
            if root and uri:
                candidate = (Path(root).resolve() / uri).resolve()
                if not candidate.is_relative_to(Path(root).resolve()):
                    raise ValueError('SARIF location outside selected root')
            findings.append({'rule': str(result.get('ruleId', 'unknown')),
                'severity': str(result.get('level', 'warning')),
                'file': uri, 'line': int(line),
                'evidence': str((result.get('message') or {}).get('text', ''))[:200],
                'recommendation': 'Manual source review and safe reproduction required',
                'status': 'potential', 'source': 'CodeQL'})
    return findings


def compare_findings(semgrep, codeql):
    """Group findings by file and line; overlap is NOT confirmation."""
    def key(f):
        return (str(f.get('file', '')).replace('\\', '/'), int(f.get('line', 0)))
    a = {key(f) for f in semgrep}
    b = {key(f) for f in codeql}
    return {'semgrep_count': len(semgrep), 'codeql_count': len(codeql),
            'same_location_count': len(a & b),
            'same_locations': [{'file': f, 'line': line} for f, line in sorted(a & b)],
            'confirmed_vulnerabilities': 0}
