"""Bounded offline fuzz smoke tests against the bundled safe sample parser only."""
import os
import random
import shutil
import subprocess
import tempfile
from pathlib import Path


def run_sample_campaign(source, iterations=100, seed=42):
    source = Path(source).resolve()
    if source.name != 'parser.c' or source.parent.name != 'samples':
        raise ValueError('Only the bundled demonstration parser is supported')
    if not 1 <= iterations <= 1000:
        raise ValueError('iterations must be between 1 and 1000')
    compiler = shutil.which('clang') or shutil.which('gcc')
    if not compiler:
        raise FileNotFoundError('clang or gcc is required')
    rng = random.Random(seed)
    with tempfile.TemporaryDirectory() as directory:
        binary = Path(directory) / ('sample.exe' if os.name == 'nt' else 'sample')
        cmd = [compiler, str(source), '-o', str(binary)]
        if 'clang' in Path(compiler).name.lower():
            cmd += ['-fsanitize=address,undefined', '-fno-omit-frame-pointer']
        build = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if build.returncode:
            raise RuntimeError('Compilation failed: ' + build.stderr[-2000:])
        crashes = []
        for index in range(iterations):
            size = rng.randrange(0, 257)
            payload = bytes(rng.randrange(256) for _ in range(size)) + b'\n'
            try:
                result = subprocess.run([str(binary)], input=payload, capture_output=True, timeout=3)
                if result.returncode != 0:
                    crashes.append({'iteration': index, 'exit_code': result.returncode, 'stderr': result.stderr.decode('utf-8', 'replace')[-1000:]})
            except subprocess.TimeoutExpired:
                crashes.append({'iteration': index, 'status': 'timeout'})
        return {'target': 'bundled safe sample parser', 'iterations': iterations, 'seed': seed,
                'unexpected_outcomes': crashes, 'confirmed_android_vulnerabilities': 0}
