"""Offline evidence bundle for authorized, local crash triage; no exploitation."""
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

SIGNATURES = ('ERROR: AddressSanitizer:', 'ERROR: UndefinedBehaviorSanitizer:', 'runtime error:')

def analyze_log(log_text, source_file=None, build_id='unrecorded'):
    if not isinstance(log_text, str):
        raise TypeError('Crash log must be text')
    if len(log_text) > 2_000_000:
        raise ValueError('Crash log exceeds 2 MB limit')
    source = Path(source_file).resolve(strict=True) if source_file else None
    if source and not source.is_file():
        raise ValueError('Source must be a file')
    evidence = [signature for signature in SIGNATURES if signature in log_text]
    trace = re.findall(r'^\s*#\d+\s+.*$', log_text, flags=re.MULTILINE)[:30]
    return {
        'schema_version': 1,
        'generated_utc': datetime.now(timezone.utc).isoformat(),
        'build_id': build_id,
        'source_file': str(source) if source else None,
        'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest() if source else None,
        'log_sha256': hashlib.sha256(log_text.encode('utf-8')).hexdigest(),
        'sanitizer_signatures': evidence,
        'stack_frames': trace,
        'classification': 'crash_evidence_unverified' if evidence else 'no_sanitizer_signature',
        'reproduction_verified': False,
        'confirmed_android_vulnerability': False,
        'validation_steps': [
            'Record the exact AOSP commit, toolchain and build flags',
            'Reproduce in an isolated emulator or local fixture',
            'Confirm source-level root cause and affected versions',
            'Apply a patch and verify a regression test',
        ],
    }

def save_evidence(path, report):
    dest = Path(path)
    if dest.suffix.lower() != '.json':
        raise ValueError('Evidence export must use .json')
    dest.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
    return dest
