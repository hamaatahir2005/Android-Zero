/* Intentionally unsafe sample for STATIC DETECTION ONLY. Do not execute. */
#include <string.h>
void example(char *input){char buffer[8];strcpy(buffer,input);}
