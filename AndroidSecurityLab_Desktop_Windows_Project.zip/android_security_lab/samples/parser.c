#include <stdio.h>
#include <string.h>
/* Safe, bounded demonstration parser. */
int main(void){char buf[64]={0};if(!fgets(buf,sizeof(buf),stdin))return 1;printf("Parsed %zu bytes\n",strlen(buf));return 0;}
