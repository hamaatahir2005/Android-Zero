# Android Zero-Click Security Research Lab (prototype)

Local-only Windows GUI for authorized Android security research. This is an early prototype, not a complete zero-click vulnerability discovery platform. It does not exploit devices or identify confirmed zero-days.

## Build Windows EXE (Windows 10/11 x64)

1. Install Python 3.11 (64-bit) from python.org, with the Python launcher (`py`).
2. Extract this project to a folder on your Windows PC.
3. Double-click `build_windows.bat` in that folder.
4. Wait for dependency installation, automated tests, and PyInstaller packaging.
5. Find the executable at `dist\AndroidSecurityLab.exe`.

Internet access is required to install dependencies the first time. The application itself supports offline local source analysis. For Android device/emulator commands, install Android SDK platform-tools and emulator separately and put `adb` and `emulator` on PATH. A local C compiler is required for the sample parser smoke test.

## Alternative: GitHub Actions

Create a GitHub repository containing the project files (including `.github/workflows/windows-build.yml`). In GitHub, choose **Actions → Build Windows EXE → Run workflow**. After the workflow completes, download the `AndroidSecurityLab-Windows` artifact and unzip it to obtain the EXE. This workflow has not been executed here.

## Features in this prototype

- PySide6 dark GUI with tabs for dashboard, findings, crash text, sample fuzzing smoke test, and offline CVE references.
- ADB device listing and Android emulator profile listing (when tools are installed).
- Heuristic local source scanner, SQLite scan history, JSON and PDF export.
- Simple sanitizer log classification. This does **not** independently verify a vulnerability.

## Known limitations

No full CodeQL/Semgrep orchestration, real fuzzing campaign manager, emulator start/stop controls, web dashboard, installer, custom icon, or verified Windows runtime. The Windows EXE is not included in the source ZIP; build it on Windows using the instructions above.

## Testing

Run `python -m pytest -q` after installing `requirements.txt`. Latest available local test run: 3 passed on Linux. See `BUILD_REPORT.md`.

## Offline fuzzing demonstration
The Fuzzing tab runs a bounded deterministic campaign (100 cases) against the bundled safe `samples/parser.c` only. It requires Clang or GCC on the host; Clang builds with AddressSanitizer and UndefinedBehaviorSanitizer. The run does not fuzz an Android device, WhatsApp, or any remote application. Results are not zero-day discoveries.

## Emulator Manager (updated)
The graphical **Emulator Manager** tab lists installed Android Virtual Devices (AVDs),
starts a selected local AVD, and stops a selected running local emulator by serial.
It does not interact with physical devices or network-connected ADB targets.
Install Android Studio, the Android SDK Platform Tools and Emulator packages, create
an AVD, then set `ANDROID_SDK_ROOT` if tools are not on your `PATH`.
The executable needs the SDK tools installed separately; they are not bundled.

## Clang sanitizer integration (new)
The Fuzzing tab includes **Run Clang ASan/UBSan on bundled safe parser**.
It compiles a bundled teaching fixture using `-fsanitize=address,undefined` and
collects bounded process output. Requires Clang installed on the host.
The feature does **not** scan Android binaries, attach to a device, or discover
zero-click vulnerabilities. Results are explicitly classified as teaching fixtures.
The executable is built on Windows with `build_windows.bat` or the included
GitHub Actions Windows workflow. A Linux build is not a Windows EXE.


## Offline Semgrep AOSP source analysis
The **Semgrep local scan** button runs only against a user-selected local source directory, using bundled rules in `rules/android-local.yml`. Install Semgrep separately on the analysis machine; the dashboard reports a missing dependency rather than downloading it. Results are marked `potential`, stored in SQLite, and can be exported to JSON/PDF. This feature does not confirm vulnerabilities or scan remote targets. AOSP trees can be large; start with a selected component directory.

## CodeQL SARIF integration
Use the **Import CodeQL SARIF** button to load a locally generated SARIF 2.1.0 file. The **Compare scans** button compares CodeQL and Semgrep findings by file and line. Overlap is a review hint, not a confirmed vulnerability. This release does not execute CodeQL or install its CLI automatically.

## Screenshot verification
A genuine GUI screenshot requires running PySide6. The current Linux execution environment does not have PySide6, and network access to install it is unavailable. Therefore no real screenshot is included; do not treat a mockup as proof of the running app.

## Local CodeQL discovery engine
The Dashboard includes **Run local CodeQL** and **Triage evidence**. Install the official CodeQL CLI and add `codeql` to PATH, and install/resolve the official query packs before use. Choose an **authorized local source folder** and a language. CodeQL database creation and analysis run locally; large AOSP source trees require substantial RAM, storage and build dependencies. Query-pack availability and language-specific extraction are environment-dependent; the application reports CLI failures instead of fabricating findings. CodeQL results are *potential* findings only. Triage compares Semgrep and CodeQL locations and identifies sanitizer markers, but never automatically labels a vulnerability confirmed. No actual AOSP scan or real-device exploit test was performed for this release.

## Offline crash evidence export
In the desktop Crash Analyzer tab, paste a local ASan/UBSan log and select **Export crash evidence JSON**. The evidence record includes sanitizer signatures, stack frames, a log SHA-256, and an explicit unverified classification. A sanitizer signature alone is not a confirmed Android vulnerability. No Android emulator or CodeQL run was performed for this update.
