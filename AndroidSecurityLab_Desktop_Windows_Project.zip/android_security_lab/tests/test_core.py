from lab.core import scan,parse_crash,init_db,store_scan,export_json
import json

def test_scan(tmp_path):
 (tmp_path/'bad.c').write_text('strcpy(a,b);\n')
 result=scan(tmp_path)
 assert len(result)==1 and result[0]['status']=='potential'

def test_crash():
 result=parse_crash('ERROR: AddressSanitizer: heap-buffer-overflow')
 assert result['sanitizer']=='AddressSanitizer' and result['confirmed'] is False

def test_storage(tmp_path):
 conn=init_db(tmp_path/'lab.db');store_scan(conn,tmp_path,[])
 assert conn.execute('SELECT COUNT(*) FROM scans').fetchone()[0]==1
 dest=tmp_path/'out.json';export_json(dest,[])
 assert json.loads(dest.read_text())['findings']==[]
