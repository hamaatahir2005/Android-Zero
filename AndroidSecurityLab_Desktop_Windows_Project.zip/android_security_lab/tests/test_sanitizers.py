from pathlib import Path
import pytest
from lab.sanitizers import run_fixture
ROOT = Path(__file__).resolve().parents[1]

def test_reject_arbitrary_source(tmp_path):
    p = tmp_path / 'other.c'
    p.write_text('int main(){return 0;}')
    with pytest.raises(ValueError):
        run_fixture(p)

def test_safe_fixture():
    result = run_fixture(ROOT / 'samples' / 'parser.c')
    assert result['status'] in ('completed', 'unavailable', 'build_failed')
    if result['status'] == 'completed':
        assert result['sanitizer_evidence'] is False
