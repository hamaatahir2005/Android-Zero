import json
from lab.codeql_analysis import import_sarif, compare_findings

def test_sarif_import(tmp_path):
    p=tmp_path/'result.sarif'
    p.write_text(json.dumps({'version':'2.1.0','runs':[{'results':[{'ruleId':'test-rule','level':'warning','message':{'text':'review'},'locations':[{'physicalLocation':{'artifactLocation':{'uri':'demo.c'},'region':{'startLine':8}}}]}]}]}))
    f=import_sarif(p)
    assert len(f)==1 and f[0]['status']=='potential' and f[0]['line']==8

def test_overlap_not_confirmation():
    f={'file':'demo.c','line':8}
    result=compare_findings([f],[f])
    assert result['same_location_count']==1
    assert result['confirmed_vulnerabilities']==0

def test_invalid_version(tmp_path):
    p=tmp_path/'bad.json';p.write_text('{"version":"1.0"}')
    try: import_sarif(p)
    except ValueError: pass
    else: assert False
