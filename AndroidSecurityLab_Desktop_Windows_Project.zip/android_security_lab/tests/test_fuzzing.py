import pytest
from pathlib import Path
from lab.fuzzing import run_sample_campaign


def test_reject_non_sample(tmp_path):
    other = tmp_path / 'other.c'
    other.write_text('int main(void){return 0;}')
    with pytest.raises(ValueError):
        run_sample_campaign(other)


def test_reject_unbounded_campaign():
    source = Path(__file__).resolve().parents[1] / 'samples' / 'parser.c'
    with pytest.raises(ValueError):
        run_sample_campaign(source, iterations=100000)
