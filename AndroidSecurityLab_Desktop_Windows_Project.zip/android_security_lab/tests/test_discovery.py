import pytest
from lab import discovery

def test_triage_does_not_confirm_crash_text():
    result = discovery.triage([{'file':'a.c','line':3}], [{'file':'a.c','line':3}], 'ERROR: AddressSanitizer: heap-buffer-overflow')
    assert result['static_analysis']['same_location_count'] == 1
    assert result['crash_evidence']['sanitizer_evidence_present']
    assert result['confirmed_android_vulnerabilities'] == 0

def test_invalid_language(tmp_path):
    with pytest.raises(ValueError, match='Unsupported'):
        discovery.run_codeql(tmp_path, 'unknown')

def test_missing_cli(tmp_path, monkeypatch):
    monkeypatch.setattr(discovery.shutil, 'which', lambda _: None)
    with pytest.raises(RuntimeError, match='not installed'):
        discovery.run_codeql(tmp_path, 'java')
