import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from lab import semgrep_analysis

class SemgrepTests(unittest.TestCase):
 def test_parse_findings(self):
  with tempfile.TemporaryDirectory() as d:
   payload={'results':[{'check_id':'android-webview-javascript-enabled','path':str(Path(d)/'Demo.java'),'start':{'line':9},'extra':{'severity':'WARNING','message':'Review bridge','lines':'setJavaScriptEnabled(true)'}}]}
   found=semgrep_analysis.parse_semgrep_json(json.dumps(payload),d)
   self.assertEqual(found[0]['file'],'Demo.java')
   self.assertEqual(found[0]['status'],'potential')
 def test_missing_semgrep(self):
  with tempfile.TemporaryDirectory() as d:
   with patch('lab.semgrep_analysis.shutil.which',return_value=None):
    with self.assertRaises(RuntimeError):semgrep_analysis.scan_local(d)
 def test_invalid_directory(self):
  with self.assertRaises(ValueError):semgrep_analysis.scan_local('/does-not-exist-android-security-lab')

if __name__=='__main__':unittest.main()
