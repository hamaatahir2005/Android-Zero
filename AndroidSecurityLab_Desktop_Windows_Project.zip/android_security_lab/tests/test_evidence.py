from lab.evidence import analyze_log, save_evidence
import json
import pytest

def test_sanitizer_not_automatically_confirmed():
    r = analyze_log('ERROR: AddressSanitizer: heap-buffer-overflow\n #0 test_frame')
    assert r['sanitizer_signatures'] and not r['confirmed_android_vulnerability']
    assert r['stack_frames']

def test_clean_log():
    assert analyze_log('nothing unusual')['classification'] == 'no_sanitizer_signature'

def test_export(tmp_path):
    path = tmp_path / 'evidence.json'
    save_evidence(path, analyze_log('runtime error: signed integer overflow'))
    assert json.loads(path.read_text())['reproduction_verified'] is False

def test_log_limit():
    with pytest.raises(ValueError): analyze_log('x' * 2_000_001)
