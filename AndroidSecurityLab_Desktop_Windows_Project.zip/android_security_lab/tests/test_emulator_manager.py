import unittest
from unittest.mock import patch, MagicMock
from lab import emulator_manager as em

class EmulatorManagerTests(unittest.TestCase):
    def test_rejects_invalid_profile(self):
        with self.assertRaises(ValueError): em.start_profile('../malicious')
    def test_rejects_physical_device_serial(self):
        with self.assertRaises(ValueError): em.stop_local_emulator('R58M12345')
    def test_rejects_arbitrary_adb_serial(self):
        with self.assertRaises(ValueError): em.stop_local_emulator('192.168.1.2:5555')
    @patch.object(em,'list_profiles',return_value=['Pixel_Test'])
    @patch.object(em,'tool_path',return_value='/usr/bin/emulator')
    @patch.object(em.subprocess,'Popen')
    def test_launch_is_explicit_local_avd(self,popen,tool,profiles):
        popen.return_value.pid=123
        self.assertEqual(em.start_profile('Pixel_Test'),123)
        self.assertEqual(popen.call_args.args[0],['/usr/bin/emulator','-avd','Pixel_Test','-no-snapshot-save'])
