import json, os, sys, traceback
from pathlib import Path
from PySide6.QtCore import Qt, QProcess
from PySide6.QtWidgets import (QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QPlainTextEdit,QFileDialog,QTabWidget,QMessageBox,QTableWidget,QTableWidgetItem,QHeaderView,QInputDialog)
from lab import core, emulator_manager, semgrep_analysis, codeql_analysis, discovery, evidence

class Window(QMainWindow):
 def __init__(self):
  super().__init__(); self.setWindowTitle('Android Zero-Click Security Research Lab'); self.resize(1150,760)
  self.findings=[]; self.semgrep_findings=[]; self.codeql_findings=[]; self.root=''; self.db=core.init_db(Path.home()/'AndroidSecurityLab.sqlite3'); self.proc=None
  tabs=QTabWidget(); self.setCentralWidget(tabs)
  self.output=QPlainTextEdit(); self.output.setReadOnly(True)
  home=QWidget(); lay=QVBoxLayout(home)
  title=QLabel('ANDROID SECURITY RESEARCH LAB'); title.setObjectName('title'); lay.addWidget(title)
  lay.addWidget(QLabel('Local, authorized analysis • Heuristic findings are not confirmed vulnerabilities'))
  bar=QHBoxLayout(); lay.addLayout(bar)
  for text,fn in [('Check dependencies',self.dependencies),('ADB devices',self.adb),('Emulator profiles',self.avds),('Scan source folder',self.scan),('Semgrep local scan',self.semgrep_scan),('Run local CodeQL',self.codeql_run),('Import CodeQL SARIF',self.codeql_import),('Triage evidence',self.triage_evidence),('Compare scans',self.compare_scans),('Export JSON',self.json_export),('Export PDF',self.pdf_export)]:
   b=QPushButton(text); b.clicked.connect(fn); bar.addWidget(b)
  lay.addWidget(self.output); tabs.addTab(home,'Dashboard / Devices')
  emupage=QWidget(); ev=QVBoxLayout(emupage)
  ev.addWidget(QLabel('Local Android emulators only — start a profile or stop a connected emulator.'))
  self.emu_log=QPlainTextEdit(); self.emu_log.setReadOnly(True)
  ebar=QHBoxLayout(); ev.addLayout(ebar)
  for label, handler in [('List profiles',self.list_profiles),('Start profile',self.start_emulator),('Stop local emulator',self.stop_emulator)]:
   eb=QPushButton(label); eb.clicked.connect(handler); ebar.addWidget(eb)
  ev.addWidget(self.emu_log); tabs.addTab(emupage,'Emulator Manager')
  scanpage=QWidget(); v=QVBoxLayout(scanpage)
  self.table=QTableWidget(0,5); self.table.setHorizontalHeaderLabels(['Rule','Severity','File','Line','Status']); self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
  v.addWidget(self.table); tabs.addTab(scanpage,'Findings')
  crash=QWidget(); cv=QVBoxLayout(crash); self.crash_text=QPlainTextEdit(); self.crash_text.setPlaceholderText('Paste local sanitizer output or stack trace here'); cv.addWidget(self.crash_text)
  export_btn=QPushButton('Export crash evidence JSON'); export_btn.clicked.connect(self.export_evidence); cv.addWidget(export_btn)
  btn=QPushButton('Analyze crash text'); btn.clicked.connect(self.crash); cv.addWidget(btn); self.crash_result=QPlainTextEdit(); self.crash_result.setReadOnly(True); cv.addWidget(self.crash_result); tabs.addTab(crash,'Crash Analyzer')
  fuzz=QWidget(); fv=QVBoxLayout(fuzz); fv.addWidget(QLabel('Local sample harness only. Requires a C compiler; no device or network fuzzing.'))
  b=QPushButton('Compile and run sample fuzz smoke test'); b.clicked.connect(self.fuzz); fv.addWidget(b); sb=QPushButton('Run Clang ASan/UBSan on bundled safe parser'); sb.clicked.connect(self.sanitizer); fv.addWidget(sb); self.fuzz_log=QPlainTextEdit(); self.fuzz_log.setReadOnly(True); fv.addWidget(self.fuzz_log); tabs.addTab(fuzz,'Fuzzing')
  cve=QWidget(); cl=QVBoxLayout(cve); cl.addWidget(QLabel('Offline reference: import public advisories into data/cve_references.json. No live CVE claims.'))
  self.cve_view=QPlainTextEdit(); self.cve_view.setReadOnly(True); cl.addWidget(self.cve_view); tabs.addTab(cve,'CVE References')
  base=Path(getattr(sys,'_MEIPASS',Path(__file__).parent)); ref=base/'data'/'cve_references.json'
  self.cve_view.setPlainText(ref.read_text(encoding='utf8') if ref.exists() else 'Reference database missing')
  self.setStyleSheet('QWidget{background:#111827;color:#e5e7eb;font-size:13px} QPushButton{background:#2563eb;padding:10px;border-radius:6px} QPushButton:hover{background:#1d4ed8} QPlainTextEdit,QTableWidget{background:#0b1220;border:1px solid #374151} QTabBar::tab{padding:12px;background:#1f2937} QTabBar::tab:selected{background:#2563eb} QLabel#title{font-size:25px;font-weight:bold;color:#93c5fd}')
 def safe(self,fn):
  try: fn()
  except Exception as e: QMessageBox.critical(self,'Operation failed',str(e)); self.output.appendPlainText('ERROR: '+str(e))
 def list_profiles(self):
  self.safe(lambda:self.emu_log.setPlainText('\n'.join(emulator_manager.list_profiles()) or 'No AVD profiles found'))
 def start_emulator(self):
  def action():
   profiles=emulator_manager.list_profiles()
   if not profiles: raise RuntimeError('No emulator profiles installed')
   profile,ok=QInputDialog.getItem(self,'Start local emulator','AVD profile',profiles,0,False)
   if ok: self.emu_log.appendPlainText(f'Started {profile}; PID {emulator_manager.start_profile(profile)}')
  self.safe(action)
 def stop_emulator(self):
  def action():
   serial,ok=QInputDialog.getText(self,'Stop emulator','Local emulator serial (e.g. emulator-5554)')
   if ok: emulator_manager.stop_local_emulator(serial.strip()); self.emu_log.appendPlainText(f'Stopped {serial}')
  self.safe(action)
 def export_evidence(self):
  path,_=QFileDialog.getSaveFileName(self,'Export local crash evidence','crash_evidence.json','JSON (*.json)')
  if not path:return
  def action():
   report=evidence.analyze_log(self.crash_text.toPlainText())
   evidence.save_evidence(path,report)
   self.crash_result.setPlainText(json.dumps(report,indent=2))
  self.safe(action)
 def dependencies(self): self.safe(lambda:self.output.setPlainText(json.dumps(core.detect_tools(),indent=2)))
 def adb(self): self.safe(lambda:self.output.setPlainText(core.devices()))
 def avds(self): self.safe(lambda:self.output.setPlainText(core.emulators()))
 def scan(self):
  folder=QFileDialog.getExistingDirectory(self,'Select authorized local source folder')
  if not folder:return
  def action():
   self.findings=core.scan(folder); self.root=folder; core.store_scan(self.db,folder,self.findings)
   self.table.setRowCount(len(self.findings))
   for i,f in enumerate(self.findings):
    for j,k in enumerate(('rule','severity','file','line','status')):self.table.setItem(i,j,QTableWidgetItem(str(f[k])))
   self.output.setPlainText(f'Scanned: {folder}\nPotential findings: {len(self.findings)}\nNo vulnerabilities automatically confirmed.')
  self.safe(action)
 def semgrep_scan(self):
  folder=QFileDialog.getExistingDirectory(self,'Select authorized local source folder for Semgrep')
  if not folder:return
  def action():
   self.findings=semgrep_analysis.scan_local(folder); self.semgrep_findings=self.findings; self.root=folder
   core.store_scan(self.db,folder,self.findings)
   self.table.setRowCount(len(self.findings))
   for i,f in enumerate(self.findings):
    for j,k in enumerate(('rule','severity','file','line','status')):
     self.table.setItem(i,j,QTableWidgetItem(str(f[k])))
   self.output.setPlainText(f'Offline Semgrep scan: {folder}\nPotential findings: {len(self.findings)}\nAll findings require manual validation.')
  self.safe(action)
 def codeql_run(self):
  folder=QFileDialog.getExistingDirectory(self,'Select authorized local source tree for CodeQL')
  if not folder:return
  language,ok=QInputDialog.getItem(self,'CodeQL language','Language',['java','cpp','python'],0,False)
  if not ok:return
  def action():
   self.output.setPlainText('CodeQL is running locally. Large source trees can take time. The interface may be temporarily unresponsive.')
   QApplication.processEvents()
   result=discovery.run_codeql(folder,language)
   self.codeql_findings=result['findings']; self.findings=self.codeql_findings; self.root=folder
   self.table.setRowCount(len(self.findings))
   for i,f in enumerate(self.findings):
    for j,k in enumerate(('rule','severity','file','line','status')):
     self.table.setItem(i,j,QTableWidgetItem(str(f[k])))
   core.store_scan(self.db,folder,self.findings)
   self.output.setPlainText(f'Local CodeQL completed: {len(self.findings)} potential findings. No vulnerabilities automatically confirmed.')
  self.safe(action)
 def triage_evidence(self):
  self.safe(lambda:self.output.setPlainText(json.dumps(discovery.triage(self.semgrep_findings,self.codeql_findings,self.crash_text.toPlainText()),indent=2)))
 def codeql_import(self):
  file,_=QFileDialog.getOpenFileName(self,'Import local CodeQL SARIF','','SARIF (*.sarif *.json)')
  if not file:return
  def action():
   self.codeql_findings=codeql_analysis.import_sarif(file)
   self.findings=self.codeql_findings
   self.table.setRowCount(len(self.findings))
   for i,f in enumerate(self.findings):
    for j,k in enumerate(('rule','severity','file','line','status')):
     self.table.setItem(i,j,QTableWidgetItem(str(f[k])))
   self.output.setPlainText(f'Imported {len(self.findings)} potential CodeQL findings. No confirmed vulnerabilities.')
  self.safe(action)
 def compare_scans(self):
  self.safe(lambda:self.output.setPlainText(json.dumps(codeql_analysis.compare_findings(self.semgrep_findings,self.codeql_findings),indent=2)))
 def json_export(self):
  file,_=QFileDialog.getSaveFileName(self,'Export JSON','findings.json','JSON (*.json)')
  if file:self.safe(lambda:core.export_json(file,self.findings))
 def pdf_export(self):
  file,_=QFileDialog.getSaveFileName(self,'Export PDF','findings.pdf','PDF (*.pdf)')
  if file:self.safe(lambda:core.export_pdf(file,self.findings))
 def crash(self): self.crash_result.setPlainText(json.dumps(core.parse_crash(self.crash_text.toPlainText()),indent=2))
 def sanitizer(self):
  def action():
   from lab.sanitizers import run_fixture
   base=Path(getattr(sys,'_MEIPASS',Path(__file__).parent))
   self.fuzz_log.setPlainText(json.dumps(run_fixture(base/'samples'/'parser.c'),indent=2))
  self.safe(action)
 def fuzz(self):
  def action():
   from lab.fuzzing import run_sample_campaign
   base=Path(getattr(sys,'_MEIPASS',Path(__file__).parent))
   result=run_sample_campaign(base/'samples'/'parser.c',iterations=100)
   self.fuzz_log.setPlainText(json.dumps(result,indent=2))
  self.safe(action)

if __name__=='__main__':
 app=QApplication(sys.argv); win=Window(); win.show(); sys.exit(app.exec())
