# Build verification report

- Date: 2026-10-28
- Source validation: `python -m pytest -q` — 24 passed.
- Desktop UI: PySide6 source included, not launched in this Linux environment (PySide6 unavailable).
- Windows EXE: not generated here. Build on Windows via `build_windows.bat` or GitHub Actions.
- Windows installer: Inno Setup script included, not compiled here.
- Android vulnerability validation: no real Android vulnerabilities confirmed.
- Some features depend on separately installed SDK, CodeQL, Semgrep and Clang tools.
