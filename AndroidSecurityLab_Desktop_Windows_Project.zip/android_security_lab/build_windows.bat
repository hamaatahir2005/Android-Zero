@echo off
setlocal
cd /d "%~dp0"
py -3 -m venv .venv
if errorlevel 1 exit /b 1
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
if errorlevel 1 exit /b 1
python -m pytest -q
if errorlevel 1 exit /b 1
pyinstaller --noconfirm --clean --onefile --windowed --name AndroidSecurityLab --add-data "data;data" --add-data "samples;samples" --add-data "rules;rules" main.py
if errorlevel 1 exit /b 1
if not exist dist\AndroidSecurityLab.exe exit /b 1
echo Build complete: dist\AndroidSecurityLab.exe
