#define AppName "Android Zero-Click Security Research Lab"
[Setup]
AppId={{B1091A52-2C10-42AF-AC4E-56B642B0F5AA}
AppName={#AppName}
AppVersion=1.0.0
DefaultDirName={localappdata}\Programs\AndroidSecurityLab
DefaultGroupName=Android Security Lab
OutputDir=installer
OutputBaseFilename=AndroidSecurityLab_Setup
Compression=lzma
SolidCompression=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64
[Files]
Source: "dist\AndroidSecurityLab.exe"; DestDir: "{app}"; Flags: ignoreversion
[Icons]
Name: "{group}\Android Security Lab"; Filename: "{app}\AndroidSecurityLab.exe"
Name: "{autodesktop}\Android Security Lab"; Filename: "{app}\AndroidSecurityLab.exe"; Tasks: desktopicon
[Tasks]
Name: "desktopicon"; Description: "Create desktop shortcut"; GroupDescription: "Additional shortcuts:"
